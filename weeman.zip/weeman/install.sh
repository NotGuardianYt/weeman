pkg update && pkg upgrade -y
pkg install git python python2 -y
pkg install openss curl -y
